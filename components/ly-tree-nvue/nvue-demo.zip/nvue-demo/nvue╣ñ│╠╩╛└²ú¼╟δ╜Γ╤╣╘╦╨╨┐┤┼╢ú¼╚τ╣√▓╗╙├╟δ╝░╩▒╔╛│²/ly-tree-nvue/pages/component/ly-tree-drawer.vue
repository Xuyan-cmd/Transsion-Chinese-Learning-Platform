<template>
	<uni-drawer ref="drawer" mode="right" :width="600">
		<scroll-view :scroll-y="true" :style="{height:appWrapperHeight}">
			<ly-tree :tree-data="treeData" showRadio node-key="id" @check="handleCheck" />
		</scroll-view>
		<view class="footer">
			<view class="footer_button footer_button-confirm" @tap="handleConfirm">
				<text class="footer_button-text footer_button-text-confirm">确定</text>
			</view>
			<view class="footer_button footer_button-cancle" @tap="close">
				<text class="footer_button-text footer_button-text-cancle">取消</text>
			</view>
		</view>
	</uni-drawer>
</template>

<script>
	import uniDrawer from './uni-drawer.vue'
	import LyTree from '@/components/ly-tree-nvue/ly-tree.vue'
	export default {
		name: 'lyTreeDrawer',
		
		components: {
			uniDrawer,
			LyTree
		},
		
		data() {
			const sysInfo = uni.getSystemInfoSync();
			
			return {
				showTree: false,
				// #ifdef H5
				appWrapperHeight: (sysInfo.screenHeight - uni.upx2px(100)) + 'px',
				// #endif
				// #ifndef H5
				appWrapperHeight: (sysInfo.windowHeight - uni.upx2px(100)) + 'px',
				// #endif
				treeData: [{
					id: 1,
					label: '一级 1',
					children: [{
						id: 3,
						label: '二级 2-1',
						children: [{
							id: 4,
							label: '三级 3-1-1'
						}, {
							id: 5,
							label: '三级 3-1-2'
						}]
					}, {
						id: 2,
						label: '二级 2-2',
						children: [{
							id: 6,
							label: '三级 3-2-1'
						}, {
							id: 7,
							label: '三级 3-2-2'
						}]
					}],
				}, {
					id: 21,
					label: '一级 21',
					children: [{
						id: 23,
						label: '二级 2-2-1',
						children: [{
							id: 24,
							label: '三级 2-3-1-1'
						}, {
							id: 25,
							label: '三级 2-3-1-2'
						}]
					}, {
						id: 22,
						label: '二级 2-2-2',
						children: [{
							id: 26,
							label: '三级 2-3-2-1'
						}, {
							id: 27,
							label: '三级 2-3-2-2'
						}]
					}],
				}, {
					id: 31,
					label: '一级 31',
					children: [{
						id: 33,
						label: '二级 3-2-1',
						children: [{
							id: 34,
							label: '三级 3-3-1-1'
						}, {
							id: 35,
							label: '三级 3-3-1-2'
						}]
					}, {
						id: 32,
						label: '二级 3-2-2',
						children: [{
							id: 36,
							label: '三级 3-3-2-1'
						}, {
							id: 37,
							label: '三级 2-3-2-2'
						}]
					}],
				}],
				selectedData: {}
			}
		},
		
		props: {
			show: Boolean
		},
		
		methods: {
			close() {
				this.$refs.drawer.close();
			},
			
			open() {
				this.$refs.drawer.open();
			},
			
			handleCheck(obj) {
				if (obj.node.checked) {
					this.selectedData = obj.data;
				} else {
					this.selectedData = void 0;
				}
			},
			
			handleConfirm() {
				this.close();
				this.$emit('confirm', this.selectedData);
			}
		}
	}
</script>

<style lang="scss">
	.footer {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		position: absolute;
		z-index: 998;
		left: 0;
		bottom: 0;
		background-color: #FFFFFF;
		width: 600rpx;
		height: 100rpx;
		overflow: hidden;
	}
	
	.footer_button {
		width: 300rpx;
		height: 100rpx;
	}
	
	.footer_button-text {
		font-size: 30rpx;
		text-align: center;
		line-height: 100rpx;
	}
	
	.footer_button-confirm {
		background-color: #409EFF;
	}
	
	.footer_button-cancle {
		background-color: #f5f5f5;
	}
	
	.footer_button-text-confirm {
		color: #fff;
	}
	
	.footer_button-text-cancle {
		color: #666;
	}
</style>
