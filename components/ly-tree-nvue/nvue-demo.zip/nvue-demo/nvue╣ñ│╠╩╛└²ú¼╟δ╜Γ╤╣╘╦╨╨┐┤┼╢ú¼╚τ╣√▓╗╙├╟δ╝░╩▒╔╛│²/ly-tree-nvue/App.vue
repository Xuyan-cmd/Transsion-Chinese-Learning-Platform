<script>
	export default {
		onLaunch: function() {
			console.log('App Launch')
		},
		onShow: function() {
			console.log('App Show')
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style>
	/* #ifndef APP-NVUE */
	body {
		font-size: 30rpx;
		line-height: 2em;
		color: #333;
		font-family: Helvetica Neue, Helvetica, sans-serif;
	}
	
	view,
	text {
		font-size: 30rpx;
		line-height: 2em;
		color: #333;
	}
	
	page {
		background: #fff;
	}
	
	button {
		width: 100%;
	}
	/* #endif */
</style>
